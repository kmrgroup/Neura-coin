"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Brain, Zap, Scale, Coins, Users, Globe } from "lucide-react"

export default function FeaturesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const features = [
    {
      icon: <Brain className="w-10 h-10 text-blue-400" />,
      title: "AI-Driven Proof-of-Work",
      description: "Intelligent mining that adapts and evolves.",
    },
    {
      icon: <Zap className="w-10 h-10 text-yellow-400" />,
      title: "24-Hour Auto-Mining",
      description: "Press 'Mine' once a day & earn continuously for 24 hours.",
    },
    {
      icon: <Scale className="w-10 h-10 text-green-400" />,
      title: "Fair Token Distribution",
      description: "Ensuring fair mining rewards & anti-whale protection.",
    },
    {
      icon: <Coins className="w-10 h-10 text-purple-400" />,
      title: "Seamless Transactions",
      description: "Ultra-fast, low-cost transactions across the network.",
    },
    {
      icon: <Users className="w-10 h-10 text-pink-400" />,
      title: "Referral & Rewards",
      description: "Earn more with our invite & earn system.",
    },
    {
      icon: <Globe className="w-10 h-10 text-cyan-400" />,
      title: "Community-Powered",
      description: "Your vote shapes Neura Coin's future development.",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-purple-950/50 to-black/50 backdrop-blur-sm" id="features">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-6xl mx-auto"
        >
          <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-4 text-blue-400 text-center">
            🔹 Features & Benefits
          </motion.h2>

          <motion.h3
            variants={itemVariants}
            className="text-2xl md:text-3xl font-semibold mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600 text-center"
          >
            Why Choose Neura Coin?
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="bg-gradient-to-br from-blue-900/10 to-purple-900/10 p-6 rounded-xl border border-purple-800/20 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300 group"
              >
                <div className="mb-4 transform group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h4 className="text-xl font-semibold mb-2 text-white group-hover:text-blue-400 transition-colors duration-300">
                  🧠 {feature.title}
                </h4>
                <p className="text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

