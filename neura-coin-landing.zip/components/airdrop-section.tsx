"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Check, Twitter, Send, Award } from "lucide-react"

export default function AirdropSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const tasks = [
    "Follow us on X (Twitter) & Telegram",
    "Retweet & Tag 3 Friends",
    "Complete Simple Tasks (Like, Share, Subscribe, etc.)",
    "Submit Your Wallet Address & Receive NEURA Tokens!",
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-purple-950/50 to-black/50 backdrop-blur-sm" id="airdrop">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-5xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-blue-400">
              🔹 🚀 Airdrop: Claim Free Neura Coins!
            </h2>

            <h3 className="text-2xl md:text-3xl font-semibold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
              Join Our Exclusive Airdrop & Be Part of the Future!
            </h3>

            <p className="text-xl text-yellow-300 font-semibold">
              🎁 Limited-Time Giveaway: Get FREE NEURA before the official launch!
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <motion.div variants={itemVariants}>
              <h4 className="text-xl font-semibold mb-6 text-white">🔹 How to Participate?</h4>

              <div className="space-y-4">
                {tasks.map((task, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 bg-gradient-to-br from-blue-900/10 to-purple-900/10 p-4 rounded-lg border border-purple-800/20"
                  >
                    <div className="mt-0.5 bg-green-500/20 p-1 rounded-full">
                      <Check className="w-4 h-4 text-green-500" />
                    </div>
                    <p className="text-gray-200">{task}</p>
                  </div>
                ))}
              </div>

              <div className="mt-8 bg-gradient-to-br from-yellow-900/20 to-yellow-600/10 p-6 rounded-xl border border-yellow-500/30">
                <div className="flex items-center gap-3 mb-3">
                  <Award className="w-6 h-6 text-yellow-400" />
                  <h5 className="text-lg font-semibold text-yellow-300">Extra Rewards!</h5>
                </div>
                <p className="text-gray-200">
                  Invite more friends & climb the Airdrop Leaderboard to unlock exclusive bonuses!
                </p>
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 p-6 rounded-xl border border-purple-500/30 backdrop-blur-sm"
            >
              <h4 className="text-xl font-semibold mb-6 text-white text-center">Join the Airdrop Now!</h4>

              <form className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 mb-1 block">Your Name</label>
                  <Input
                    placeholder="Enter your name"
                    className="bg-black/50 border-purple-800/50 focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-400 mb-1 block">Email Address</label>
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    className="bg-black/50 border-purple-800/50 focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-400 mb-1 block">Wallet Address (ERC-20)</label>
                  <Input placeholder="0x..." className="bg-black/50 border-purple-800/50 focus:border-purple-500" />
                </div>

                <div>
                  <label className="text-sm text-gray-400 mb-1 block">Twitter Username</label>
                  <div className="flex">
                    <div className="bg-blue-900/30 flex items-center px-3 rounded-l-md border border-r-0 border-purple-800/50">
                      <Twitter className="w-4 h-4 text-blue-400" />
                    </div>
                    <Input
                      placeholder="@username"
                      className="bg-black/50 border-purple-800/50 focus:border-purple-500 rounded-l-none"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Submit & Claim NEURA
                </Button>
              </form>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

