"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { Download, MousePointer, Trophy } from "lucide-react"

export default function HowToGetSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const steps = [
    {
      icon: <Download className="w-12 h-12 text-blue-400" />,
      number: "1️⃣",
      title: "Download the Neura Coin App",
      description: "(Coming soon!)",
    },
    {
      icon: <MousePointer className="w-12 h-12 text-green-400" />,
      number: "2️⃣",
      title: "Tap &quot;Mine&quot;",
      description: "Activate AI-powered mining with one click.",
    },
    {
      icon: <Trophy className="w-12 h-12 text-yellow-400" />,
      number: "3️⃣",
      title: "Earn Rewards",
      description: "Get Neura Coins every 24 hours without any extra effort!",
    },
  ]

  return (
    <section className="py-20 bg-black/50 backdrop-blur-sm" id="how-to-get">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-5xl mx-auto"
        >
          <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-4 text-blue-400 text-center">
            🔹 How to Get Neura Coin?
          </motion.h2>

          <motion.h3
            variants={itemVariants}
            className="text-2xl md:text-3xl font-semibold mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600 text-center"
          >
            Start Mining in 3 Easy Steps!
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="bg-gradient-to-br from-blue-900/10 to-purple-900/10 p-8 rounded-xl border border-purple-800/20 backdrop-blur-sm text-center"
              >
                <div className="flex justify-center mb-4">{step.icon}</div>
                <h4 className="text-2xl font-bold mb-2 text-white">
                  {step.number} {step.title}
                </h4>
                <p className="text-gray-300">{step.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            variants={itemVariants}
            className="text-center bg-gradient-to-br from-blue-900/20 to-purple-900/20 p-6 rounded-xl border border-purple-500/30 backdrop-blur-sm"
          >
            <p className="text-lg text-gray-200 mb-4">
              👉 Want more? Buy, trade, or stake NEURA on upcoming crypto exchanges &amp; DeFi platforms!
            </p>
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
            >
              Join Waitlist
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

