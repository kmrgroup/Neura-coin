"use client"

import { useRef, useMemo } from "react"
import { useFrame } from "@react-three/fiber"
import * as THREE from "three"

// Neural network node
interface Node {
  position: THREE.Vector3
  connections: number[]
  speed: number
}

export default function NeuralNetwork() {
  const linesRef = useRef<THREE.LineSegments>(null)
  const pointsRef = useRef<THREE.Points>(null)

  // Create nodes and connections
  const { nodes, positions, connections } = useMemo(() => {
    const nodeCount = 100
    const nodes: Node[] = []
    const positions = new Float32Array(nodeCount * 3)
    const connectionPairs: number[][] = []

    // Create nodes with random positions
    for (let i = 0; i < nodeCount; i++) {
      const x = (Math.random() - 0.5) * 20
      const y = (Math.random() - 0.5) * 20
      const z = (Math.random() - 0.5) * 20

      positions[i * 3] = x
      positions[i * 3 + 1] = y
      positions[i * 3 + 2] = z

      nodes.push({
        position: new THREE.Vector3(x, y, z),
        connections: [],
        speed: 0.01 + Math.random() * 0.02,
      })
    }

    // Create connections between nodes
    for (let i = 0; i < nodeCount; i++) {
      const connectionCount = 2 + Math.floor(Math.random() * 3) // 2-4 connections per node

      for (let j = 0; j < connectionCount; j++) {
        const target = Math.floor(Math.random() * nodeCount)
        if (target !== i && !nodes[i].connections.includes(target)) {
          nodes[i].connections.push(target)
          connectionPairs.push([i, target])
        }
      }
    }

    // Create connection lines
    const connections = new Float32Array(connectionPairs.length * 6)
    connectionPairs.forEach((pair, index) => {
      const [from, to] = pair
      connections[index * 6] = positions[from * 3]
      connections[index * 6 + 1] = positions[from * 3 + 1]
      connections[index * 6 + 2] = positions[from * 3 + 2]
      connections[index * 6 + 3] = positions[to * 3]
      connections[index * 6 + 4] = positions[to * 3 + 1]
      connections[index * 6 + 5] = positions[to * 3 + 2]
    })

    return { nodes, positions, connections }
  }, [])

  // Animate the neural network
  useFrame(({ clock }) => {
    const time = clock.getElapsedTime()

    // Update node positions
    if (pointsRef.current && pointsRef.current.geometry) {
      const positions = pointsRef.current.geometry.attributes.position.array as Float32Array

      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i]

        // Move nodes in a wave-like pattern
        const x = node.position.x + Math.sin(time * node.speed + i) * 0.01
        const y = node.position.y + Math.cos(time * node.speed + i * 0.5) * 0.01
        const z = node.position.z + Math.sin(time * node.speed + i * 0.3) * 0.01

        positions[i * 3] = x
        positions[i * 3 + 1] = y
        positions[i * 3 + 2] = z

        node.position.set(x, y, z)
      }

      pointsRef.current.geometry.attributes.position.needsUpdate = true
    }

    // Update connection lines
    if (linesRef.current && linesRef.current.geometry) {
      const linePositions = linesRef.current.geometry.attributes.position.array as Float32Array
      let index = 0

      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i]

        for (const target of node.connections) {
          linePositions[index++] = node.position.x
          linePositions[index++] = node.position.y
          linePositions[index++] = node.position.z
          linePositions[index++] = nodes[target].position.x
          linePositions[index++] = nodes[target].position.y
          linePositions[index++] = nodes[target].position.z
        }
      }

      linesRef.current.geometry.attributes.position.needsUpdate = true
    }
  })

  return (
    <group>
      {/* Nodes */}
      <points ref={pointsRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={positions.length / 3} array={positions} itemSize={3} />
        </bufferGeometry>
        <pointsMaterial size={0.15} color="#a855f7" sizeAttenuation transparent opacity={0.8} />
      </points>

      {/* Connections */}
      <lineSegments ref={linesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={connections.length / 3}
            array={connections}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#4f46e5" transparent opacity={0.2} linewidth={1} />
      </lineSegments>

      {/* Ambient light for better visibility */}
      <ambientLight intensity={0.5} />
    </group>
  )
}

