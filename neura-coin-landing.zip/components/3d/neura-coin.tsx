"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { MeshDistortMaterial } from "@react-three/drei"
import type * as THREE from "three"

export default function NeuraCoin() {
  const coinRef = useRef<THREE.Mesh>(null)
  const innerRef = useRef<THREE.Mesh>(null)

  // Rotate the coin
  useFrame((state) => {
    if (coinRef.current) {
      coinRef.current.rotation.y += 0.01
      coinRef.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.2
    }

    if (innerRef.current) {
      innerRef.current.rotation.y -= 0.02
      innerRef.current.rotation.z += 0.01
    }
  })

  return (
    <group>
      {/* Outer coin */}
      <mesh ref={coinRef}>
        <cylinderGeometry args={[2, 2, 0.2, 64]} />
        <MeshDistortMaterial
          color="#4f46e5"
          distort={0.2}
          speed={2}
          metalness={0.9}
          roughness={0.2}
          emissive="#2563eb"
          emissiveIntensity={0.5}
        />

        {/* Inner symbol */}
        <mesh ref={innerRef} position={[0, 0, 0.11]}>
          <torusGeometry args={[0.8, 0.2, 16, 32]} />
          <meshStandardMaterial
            color="#a855f7"
            emissive="#a855f7"
            emissiveIntensity={0.8}
            metalness={1}
            roughness={0.3}
          />

          {/* Center dot */}
          <mesh position={[0, 0, 0]}>
            <sphereGeometry args={[0.3, 32, 32]} />
            <meshStandardMaterial
              color="#ffffff"
              emissive="#ffffff"
              emissiveIntensity={1}
              metalness={1}
              roughness={0.2}
            />
          </mesh>
        </mesh>
      </mesh>

      {/* Light setup */}
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#a855f7" />

      {/* Glow effect */}
      <mesh scale={[2.5, 2.5, 0.1]} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.9, 1.1, 32]} />
        <meshBasicMaterial color="#4f46e5" transparent opacity={0.3} />
      </mesh>
    </group>
  )
}

