"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { Rocket, Smartphone, Link, Globe } from "lucide-react"

export default function RoadmapSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const phases = [
    {
      icon: <Rocket className="w-8 h-8 text-blue-400" />,
      title: "Phase 1: Token Launch & Airdrop",
      items: ["Initial token distribution", "Community building", "Website launch", "Social media presence"],
      active: true,
    },
    {
      icon: <Smartphone className="w-8 h-8 text-green-400" />,
      title: "Phase 2: Neura Coin App Release",
      items: ["Mobile app development", "AI mining algorithm implementation", "Security audits", "Beta testing"],
      active: false,
    },
    {
      icon: <Link className="w-8 h-8 text-purple-400" />,
      title: "Phase 3: Staking & DeFi Integration",
      items: ["Staking mechanism", "Yield farming", "Liquidity pools", "Partnerships with DeFi platforms"],
      active: false,
    },
    {
      icon: <Globe className="w-8 h-8 text-yellow-400" />,
      title: "Phase 4: Exchange Listings & Global Adoption",
      items: ["Major exchange listings", "Marketing campaigns", "Enterprise partnerships", "Ecosystem expansion"],
      active: false,
    },
  ]

  return (
    <section className="py-20 bg-black/50 backdrop-blur-sm" id="roadmap">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-5xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-blue-400">🔹 Roadmap & Future Plans</h2>
          </motion.div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-[15px] md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-500 to-purple-600 z-0"></div>

            {/* Phases */}
            <div className="space-y-12 relative z-10">
              {phases.map((phase, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className={`flex flex-col md:flex-row ${index % 2 === 0 ? "md:flex-row-reverse" : ""} items-start gap-8`}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 w-8 h-8 rounded-full border-4 border-purple-600 bg-black z-20"></div>

                  {/* Content */}
                  <div
                    className={`ml-12 md:ml-0 w-full md:w-[calc(50%-2rem)] ${index % 2 === 0 ? "md:text-left" : "md:text-right"}`}
                  >
                    <div
                      className={`bg-gradient-to-br ${phase.active ? "from-blue-900/30 to-purple-900/30 border-blue-500/50" : "from-blue-900/10 to-purple-900/10 border-purple-800/20"} p-6 rounded-xl border backdrop-blur-sm`}
                    >
                      <div className={`flex items-center gap-3 mb-4 ${index % 2 === 0 ? "" : "md:flex-row-reverse"}`}>
                        <div className="p-2 bg-black/50 rounded-lg">{phase.icon}</div>
                        <h4 className="text-xl font-semibold text-white">{phase.title}</h4>
                      </div>

                      <ul className={`space-y-2 ${index % 2 === 0 ? "" : "md:pl-0"}`}>
                        {phase.items.map((item, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                            <span className="text-gray-300">{item}</span>
                          </li>
                        ))}
                      </ul>

                      {phase.active && (
                        <div className="mt-4 inline-block bg-blue-500/20 px-3 py-1 rounded-full text-blue-300 text-sm">
                          Current Phase
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <motion.div variants={itemVariants} className="text-center mt-16">
            <Button variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-950/30">
              🔗 View Full Roadmap
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

