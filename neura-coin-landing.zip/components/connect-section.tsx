"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Twitter, MessageSquare, Globe, DiscIcon as Discord } from "lucide-react"

export default function ConnectSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const socialLinks = [
    {
      icon: <Globe className="w-6 h-6" />,
      label: "Website",
      url: "www.neuracoin.com",
      color: "text-blue-400 hover:text-blue-300",
    },
    {
      icon: <Twitter className="w-6 h-6" />,
      label: "Twitter",
      url: "@NeuraCoin",
      color: "text-sky-400 hover:text-sky-300",
    },
    {
      icon: <MessageSquare className="w-6 h-6" />,
      label: "Telegram",
      url: "Join Community",
      color: "text-blue-400 hover:text-blue-300",
    },
    {
      icon: <Discord className="w-6 h-6" />,
      label: "Discord",
      url: "NeuraCoin Official",
      color: "text-indigo-400 hover:text-indigo-300",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-purple-950/50 to-black/50 backdrop-blur-sm" id="connect">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-5xl mx-auto"
        >
          <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-12 text-blue-400 text-center">
            🔹 Stay Connected
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <motion.div variants={itemVariants}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {socialLinks.map((link, index) => (
                  <a
                    key={index}
                    href="#"
                    className="bg-gradient-to-br from-blue-900/10 to-purple-900/10 p-6 rounded-xl border border-purple-800/20 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300 flex flex-col items-center text-center"
                  >
                    <div className={`mb-3 ${link.color}`}>{link.icon}</div>
                    <h4 className="text-lg font-semibold mb-1 text-white">{link.label}</h4>
                    <p className="text-gray-400">{link.url}</p>
                  </a>
                ))}
              </div>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 p-6 rounded-xl border border-purple-500/30 backdrop-blur-sm"
            >
              <h4 className="text-xl font-semibold mb-6 text-white text-center">📩 Subscribe to our newsletter</h4>

              <p className="text-gray-300 mb-6 text-center">Get updates & exclusive rewards directly to your inbox!</p>

              <div className="flex flex-col sm:flex-row gap-3">
                <Input
                  placeholder="Enter your email"
                  className="bg-black/50 border-purple-800/50 focus:border-purple-500"
                />
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white whitespace-nowrap">
                  Subscribe
                </Button>
              </div>

              <p className="text-xs text-gray-500 mt-4 text-center">
                By subscribing, you agree to receive updates from Neura Coin. You can unsubscribe at any time.
              </p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

