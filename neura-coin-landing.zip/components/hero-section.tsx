"use client"

import { Button } from "@/components/ui/button"
import { Canvas } from "@react-three/fiber"
import { Suspense } from "react"
import NeuraCoin from "@/components/3d/neura-coin"
import NeuralNetwork from "@/components/3d/neural-network"
import { motion } from "framer-motion"

export default function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* 3D Background */}
      <div className="absolute inset-0 z-0">
        <Canvas>
          <Suspense fallback={null}>
            <NeuralNetwork />
          </Suspense>
        </Canvas>
      </div>

      {/* Content */}
      <div className="container relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 px-4">
        <div className="w-full md:w-1/2 space-y-6">
          <motion.h1
            className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            The Future of AI-Powered Crypto Mining is Here!
          </motion.h1>

          <motion.p
            className="text-xl text-gray-300"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Neura Coin (NEURA) – A next-gen cryptocurrency powered by AI-driven neural networks. Secure, scalable, and
            easy to mine.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 pt-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
              onClick={() => scrollToSection("how-to-get")}
            >
              🚀 Get Started
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-purple-500 text-purple-400 hover:bg-purple-950/30"
              onClick={() => scrollToSection("airdrop")}
            >
              🎁 Join Airdrop
            </Button>
          </motion.div>
        </div>

        <div className="w-full md:w-1/2 h-[300px] md:h-[500px]">
          <Canvas>
            <Suspense fallback={null}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <NeuraCoin />
            </Suspense>
          </Canvas>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{
          y: [0, 10, 0],
        }}
        transition={{
          duration: 1.5,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
        }}
      >
        <div className="w-8 h-12 rounded-full border-2 border-purple-500 flex justify-center">
          <div className="w-1 h-3 bg-purple-500 rounded-full mt-2"></div>
        </div>
      </motion.div>
    </section>
  )
}

