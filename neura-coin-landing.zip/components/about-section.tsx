"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"

export default function AboutSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  return (
    <section className="py-20 bg-black/50 backdrop-blur-sm" id="about">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-4xl mx-auto text-center"
        >
          <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-4 text-blue-400">
            🔹 About Neura Coin
          </motion.h2>

          <motion.h3
            variants={itemVariants}
            className="text-2xl md:text-3xl font-semibold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600"
          >
            The AI Revolution in Cryptocurrency
          </motion.h3>

          <motion.p variants={itemVariants} className="text-lg text-gray-300 mb-10">
            Neura Coin is a decentralized cryptocurrency powered by AI-based Proof-of-Work using Feedforward Neural
            Networks (POW-FNN).
          </motion.p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              "AI-Powered Mining – Smart mining with neural networks optimizing rewards.",
              "Scalable & Fast – Designed for high-speed transactions and minimal fees.",
              "Eco-Friendly Mining – Unlike traditional PoW, our AI-based system reduces energy consumption.",
              "Secure & Decentralized – Built on Polygon blockchain for reliability and transparency.",
            ].map((feature, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 p-6 rounded-xl border border-purple-800/30 backdrop-blur-sm"
              >
                <p className="text-left">
                  <span className="text-green-400 mr-2">✅</span>
                  {feature}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

