import HeroSection from "@/components/hero-section"
import AboutSection from "@/components/about-section"
import FeaturesSection from "@/components/features-section"
import HowToGetSection from "@/components/how-to-get-section"
import AirdropSection from "@/components/airdrop-section"
import RoadmapSection from "@/components/roadmap-section"
import ConnectSection from "@/components/connect-section"
import FinalCtaSection from "@/components/final-cta-section"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-black to-purple-950 text-white overflow-hidden">
      <HeroSection />
      <AboutSection />
      <FeaturesSection />
      <HowToGetSection />
      <AirdropSection />
      <RoadmapSection />
      <ConnectSection />
      <FinalCtaSection />
    </main>
  )
}

